<?php
/**
 * Created by PhpStorm.
 * User: antoni
 * Date: 18/05/18
 * Time: 21.15
 */

define('CONSUMER_KEY','C7VSn0nf9hXfmE2k9IptG0bze');
define('CONSUMER_SECRET','bdjOUsa7hxIgFkecJZnm4VuDIdcgsWmWvi1IBFQ53YF400GBRK');
define('OAUTH_CALLBACK','http://127.0.0.1/php/complex/process.php');


?>